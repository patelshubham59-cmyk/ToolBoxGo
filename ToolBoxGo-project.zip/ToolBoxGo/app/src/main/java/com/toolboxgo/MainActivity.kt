package com.toolboxgo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() { override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { ToolBoxApp() } } }

@Composable fun ToolBoxApp() {
 var selected by remember { mutableStateOf("Home") }
 MaterialTheme { Scaffold(topBar={ TopAppBar(title={ Text("ToolBox Go ✨") }) }) { pad ->
 LazyColumn(modifier=Modifier.padding(pad).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
 item { Text("Your everyday tools, all in one place", style=MaterialTheme.typography.titleMedium) }
 item { Text("FREE • Simple • Fast", color=MaterialTheme.colorScheme.primary) }
 items(listOf("Calculator","Text Counter","Unit Converter","QR Scanner","Internet Speed","Battery Info")) { tool ->
 Card(onClick={selected=tool}, modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text(tool, style=MaterialTheme.typography.titleLarge); Text("Tap to open") } }
 }
 item { if(selected=="Text Counter") TextCounter() else if(selected=="Calculator") SimpleCalc() else if(selected=="Unit Converter") Converter() else if(selected!="Home") Text("$selected is coming in the next update!", style=MaterialTheme.typography.titleMedium) }
 }
 } }
}
@Composable fun TextCounter(){ var txt by remember { mutableStateOf("") }; Column(verticalArrangement=Arrangement.spacedBy(8.dp)){ Text("Text Counter",style=MaterialTheme.typography.titleLarge); OutlinedTextField(txt,{txt=it},label={Text("Enter or paste text")},modifier=Modifier.fillMaxWidth()); Text("Characters: ${txt.length}  •  Words: ${txt.trim().split(Regex("\\s+")).count { it.isNotEmpty() }}") } }
@Composable fun SimpleCalc(){ var a by remember { mutableStateOf("") }; var b by remember { mutableStateOf("") }; Column(verticalArrangement=Arrangement.spacedBy(8.dp)){ Text("Add numbers",style=MaterialTheme.typography.titleLarge); OutlinedTextField(a,{a=it},label={Text("First number")}); OutlinedTextField(b,{b=it},label={Text("Second number")}); Text("Result: ${(a.toDoubleOrNull()?:0.0)+(b.toDoubleOrNull()?:0.0)}") } }
@Composable fun Converter(){ var value by remember { mutableStateOf("") }; Column(verticalArrangement=Arrangement.spacedBy(8.dp)){ Text("Kilometres ↔ Miles",style=MaterialTheme.typography.titleLarge); OutlinedTextField(value,{value=it},label={Text("Kilometres")}); Text("Miles: ${((value.toDoubleOrNull()?:0.0)*0.621371).let { String.format("%.3f",it) }}") } }
